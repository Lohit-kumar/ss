usage:
  put BurpLoader.jar and burpsuite_pro_v1.5.01.jar in the same directory


  execute in Burp suit.bat

- Enjoy Burp Pro -

:)